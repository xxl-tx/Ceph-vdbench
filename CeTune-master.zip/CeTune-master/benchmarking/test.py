import os
print os.path.dirname(__file__)
