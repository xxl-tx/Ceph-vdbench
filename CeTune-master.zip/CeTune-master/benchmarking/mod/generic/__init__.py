__all__ = ['generic', 'hook']


