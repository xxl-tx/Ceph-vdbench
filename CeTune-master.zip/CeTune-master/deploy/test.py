#/usr/bin/python

import deploy_rgw

rgw = deploy_rgw.Deploy_RGW()

rgw.deploy()
